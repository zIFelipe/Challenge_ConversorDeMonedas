package Alura_Latam.Challenge_Foro_Hub.model.usuarios;



public record DatosActualizarUsuario(String clave, String login, String email, Boolean activo) {
}
