package Alura_Latam.Challenge_Foro_Hub.model.respuesta.validaciones;

import Alura_Latam.Challenge_Foro_Hub.model.respuesta.DatosRegistrarRespuesta;

public interface ValidarRegistroRespuesta {
    void validar(DatosRegistrarRespuesta respuesta);
}
