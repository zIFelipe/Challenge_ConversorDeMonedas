package Alura_Latam.Challenge_Foro_Hub.model.usuarios.validaciones;


public interface ValidarListadoUsuario {
    void validar(Long id);

    void validarNombre(String nombre);
}
