package Alura_Latam.Challenge_Foro_Hub.model.curso;

public enum Categoria  {

    FRONT_END,
    BACK_END,
    HABILIDADES_BLANDAS,
    INTELIGENCIA_ARTIFICIAL,
    BASES_DE_DATOS,
    GIT_HUB
}
