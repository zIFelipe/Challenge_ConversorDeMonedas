package Alura_Latam.Challenge_Foro_Hub.model.topico.validaciones;

import Alura_Latam.Challenge_Foro_Hub.model.topico.DatosRegistrarTopico;

public interface ValidarRegistroTopico {
    void validar(DatosRegistrarTopico datosRegistrarTopico);
}
