package Alura_Latam.Challenge_Foro_Hub.model.respuesta;

public record DatosActualizarRespuesta(String mensaje, Boolean cerrado) {
}
