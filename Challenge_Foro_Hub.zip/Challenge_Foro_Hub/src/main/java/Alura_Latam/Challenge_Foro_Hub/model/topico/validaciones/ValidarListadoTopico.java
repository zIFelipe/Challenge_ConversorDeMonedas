package Alura_Latam.Challenge_Foro_Hub.model.topico.validaciones;

public interface ValidarListadoTopico {
    void validar(Long id);
}
