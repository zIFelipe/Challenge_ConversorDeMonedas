package Alura_Latam.Challenge_Foro_Hub.model.topico.validaciones;

import Alura_Latam.Challenge_Foro_Hub.model.topico.DatosActualizarTopico;

public interface ValidarActualizacionTopico {

    void validar(DatosActualizarTopico topico);
}
