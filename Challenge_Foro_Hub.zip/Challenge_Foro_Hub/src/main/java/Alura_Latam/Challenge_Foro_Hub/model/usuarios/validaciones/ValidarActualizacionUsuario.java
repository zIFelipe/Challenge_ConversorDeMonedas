package Alura_Latam.Challenge_Foro_Hub.model.usuarios.validaciones;

import Alura_Latam.Challenge_Foro_Hub.model.usuarios.DatosActualizarUsuario;

public interface ValidarActualizacionUsuario {
    void validar(DatosActualizarUsuario usuario);
}
