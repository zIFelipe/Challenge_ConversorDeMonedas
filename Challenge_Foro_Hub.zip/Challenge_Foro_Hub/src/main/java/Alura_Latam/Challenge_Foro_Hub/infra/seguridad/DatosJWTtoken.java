package Alura_Latam.Challenge_Foro_Hub.infra.seguridad;

public record DatosJWTtoken(String JWTtoken) {
}
