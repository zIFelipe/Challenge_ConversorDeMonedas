package Alura_Latam.Challenge_Foro_Hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeForoHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
